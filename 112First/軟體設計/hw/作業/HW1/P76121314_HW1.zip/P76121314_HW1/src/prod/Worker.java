package prod;

import java.util.HashSet;
import java.util.Set;

public class Worker extends Person {
	// set variable
	protected Set<Project> projects;
	
	// use constructor to initiate Worker object
	public Worker(String initialName, String initialAddress, String initialsocialsecurityNumber) {
		super(initialName, initialAddress, initialsocialsecurityNumber);
		projects = new HashSet<>();
	}
	
	// get worker information
	public String getinf() {
		return (name +" "+ address +" "+socialsecurityNumber);
	}
	
	//add project
	public void addproject(Project project) {
		projects.add(project);
		project.workers.add(this);
	}
	
	// work on these projects
	public void work() {
		System.out.println(this.name+" works on these projects:");
		int index=1;
		for(Project project:projects) {
			System.out.println("Project No."+index+":"+project.getinf());
			index++;
			}
		System.out.println("");
		}
}
