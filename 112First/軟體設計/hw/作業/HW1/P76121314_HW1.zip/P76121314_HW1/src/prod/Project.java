package prod;

import java.util.HashSet;
import java.util.Set;
public class Project {
	// set variable
	private String name;
	private int budget;
	private int internalPriority;//Priority 1~5 --> low~high
	private Manager manager;
	protected Set<Worker> workers;
	
	// use constructor to initiate Project object
	public Project(String name, int budget, int internalPriority, Manager manager) {
		this.name = name;
		this.budget = budget;
		this.internalPriority = internalPriority;
		this.manager = manager;
		// set responsible manager
		this.manager.addresponsibleProject(this);
		workers = new HashSet<>();
		
	}
	
	// get project information 
	public String getinf() {
		return ("Project { "+"name:"+this.name+" "+"budget:"+this.budget+" "+"internalPriority:"+this.internalPriority+" "+"manager:"+this.manager.name+" }");
	}
	
	//securing resource
	public void securingResources() {
		System.out.print("This project's priority is "+this.internalPriority);
	}
	
	//staff worker
	public void staff(Worker worker) {
		workers.add(worker);
		worker.projects.add(this);
	}
	
	// display information about the workers who are staffed on this project
	public void displaywokersinf() {
		System.out.println(this.name+"'s workers list:");
		int index=1;
		for(Worker worker:workers) {
		System.out.println("No."+index+" "+worker.getinf());
		index++;
		}
		System.out.println("");
	}	
	
	// cost time on this project
	public float costtime() {
		float time = 60;//example
		return time;
	}
	
}
