package prod;

import java.util.Set;
import java.util.HashSet;
import java.util.Scanner;

public class Company {
	// set variable
	private String name, address, primary_product, phone_number;
	protected int hourly_wage = 180;
	private Set<Person> employee;
	private Set<Department> departments;

	// use constructor to initiate Company object
	public Company(String initialName, String initialAddress, String initialPhonenumber, String initialPrimaryproduct) {
		name = initialName;
		address = initialAddress;
		phone_number = initialPhonenumber;
		primary_product = initialPrimaryproduct;
		// 初始化employee set
		employee = new HashSet<>();
		departments = new HashSet<>();
		Department department = new Department(this.primary_product);
		Scanner scanner = new Scanner(System.in);
		System.out.print("Please input cost： ");
		int cost = scanner.nextInt();
		System.out.print("Please input weight： ");
		float weight = scanner.nextFloat();
		department.manufacture(this.primary_product, cost, weight);
	}

	// get information
	public String getinf() {
		return (name + " " + address + " " + phone_number + " " + primary_product);
	}

	// hire person
	public void hire(Person person) {
		this.employee.add(person);
	}

	// fire person
	public void fire(Person person) {
		this.employee.remove(person);
	}

	// display employee information
	public void displayemployeeinf() {
		System.out.println(this.name+"'s employee list:");
		int index = 1;
		for (Person person : employee) {
			System.out.println("No." + index + " " + person.getinf());
			index++;
		}
		System.out.println("");
	}

	// create department
	public Department createdepartment(String name) {
		Department department = new Department(name);
		departments.add(department);
		return department;
	}

	// disband department
	public void disabanddepartment(Department department) {
		departments.remove(department);
	}

	// display department list
	public void displaydepartmentlist() {
		System.out.println(this.name+"'s department list:");
		int index = 1;
		for (Department department : departments) {
			System.out.print("Department No." + index + ":" + department.getinf());
			index++;
		}
		System.out.println("");
	}
}
