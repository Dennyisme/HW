package prod;

import java.util.HashSet;
import java.util.Set;

public class Manager extends Person{
	// set variable
	private Set<Project> projects;
	protected Department[] department= new Department[1];
	
	// use constructor to initiate Manager object
	public Manager(String initialName, String initialAddress, String initialsocialsecurityNumber) {
		super(initialName, initialAddress, initialsocialsecurityNumber);
		projects = new HashSet<>();
	}
	
	// add the project that manager is responsible for
	public void addresponsibleProject(Project project) {
		this.projects.add(project);
	}
	
	// display the projects responsible by manager
	public void displayresponsibleProjectList() {
		System.out.println(this.name+"'s project list:");
		int index=1;
		for(Project project:projects) {
			System.out.println("Project No."+index+":"+project.getinf());
			index++;
		}
		System.out.println("");
	}
	
	// set manage department
	public void setmanagedepartment(Department department) {
		this.department[0]=department;
		department.manager[0]=this;
		}
	
	// get manager department's information
	public String getmanagedepartmentName() {
		return this.department[0].getinf();
	}
	
}
