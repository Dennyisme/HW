package prod;
public class main {
	public static void main(String[] args)
	{
		// create workers
		Worker Tony = new Worker("Tony","Taiwan","0000");
		Worker John = new Worker("John","America","0001");
		Worker Jason = new Worker("Jason","America","0002");
		
		//create manager
		Manager managerShark = new Manager("Shark","America","1111");
		
		// create  projects
		Project buildrailway = new Project("buildrailway",5000000,4,managerShark);
		Project buildhouse = new Project("builhouse",1000000,2,managerShark);
		System.out.println(buildrailway.getinf());
		System.out.println(buildhouse.getinf());
		System.out.println("");
		
		// create a company
		Company Apple = new Company("Apple","Tainan","1234","apple");
		
		// charge time
		System.out.println(Tony.chargetime(buildrailway)+" hours");
		
		// earn salary
		System.out.println(Tony.earnsalary(buildrailway, Apple)+" dollar");
		System.out.println("");

		// Apple create department
		Department GTA = Apple.createdepartment("GTA");
		System.out.println(GTA.getinf());
		System.out.println("");
		Apple.displaydepartmentlist();
		
		// company hire person
		Apple.hire(Tony);
		Apple.hire(John);
		Apple.hire(Jason);
		Apple.hire(managerShark);
		Apple.displayemployeeinf();
		
		// company fire person
		Apple.fire(John);
		Apple.displayemployeeinf();
		
		// worker add project
		Tony.addproject(buildrailway);
		Tony.addproject(buildhouse);
		Tony.work();
		Jason.addproject(buildrailway);
		Jason.addproject(buildhouse);
		Jason.work();
		
		// display buildrailway's worker list
		buildrailway.displaywokersinf();

		//display manager Shark's project list
		managerShark.displayresponsibleProjectList();
		
		//manager with department
		managerShark.setmanagedepartment(GTA);
		System.out.println(GTA.getmanagerinf());
		System.out.println("");
		
		//department with product
		GTA.manufacture("Car",6000,100.0f);
		GTA.displayproductslist();
		
	}
}
	