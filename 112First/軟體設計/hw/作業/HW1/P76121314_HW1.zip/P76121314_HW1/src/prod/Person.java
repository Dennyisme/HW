package prod;

public abstract class Person {
	// set variable
	protected String name, address, socialsecurityNumber;
	
	// use constructor to initiate Person object
	public Person(String initialName, String initialAddress, String initialsocialsecurityNumber)
	{
		name = initialName;
		address = initialAddress;
		socialsecurityNumber = initialsocialsecurityNumber;
	}
	
	//charge time to projects
	public float chargetime(Project project) {
		float time = project.costtime();
		return time;
	}
	
	//earn a salary
	public float earnsalary(Project project, Company company) {
		float money = this.chargetime(project)*company.hourly_wage;
		return money;
	}
	
	// get person information
	public String getinf() {
		return (name +" "+ address +" "+socialsecurityNumber);
	}
}