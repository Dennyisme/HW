package prod;

public class Product {
	// set variable
	private String name;
	private int cost;
	private float weight; 
	
	// use constructor to initiate Product object
	public Product(String name, int cost, float weight) {
		this.name = name;
		this.cost = cost;
		this.weight = weight;
	}
	
	// get product information
	public String getinf() {
		return ("name:"+name+" "+"cost:"+cost+" "+"weight:"+weight);
	}

}
