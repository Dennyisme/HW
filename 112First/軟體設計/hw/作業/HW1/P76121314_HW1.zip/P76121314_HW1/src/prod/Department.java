package prod;

import java.util.HashSet;
import java.util.Set;

public class Department {
	// set variable
	private String name;
	private Set<Product> products;
	protected Manager[] manager= new Manager[1];

	// use constructor to initiate Department object
	public Department(String name) {
		this.name = name;
		products = new HashSet<>();
	}
	
	// manufacture product
	public Product manufacture(String name, int cost, float weight) {
		Product product = new Product(name, cost, weight);
		products.add(product);
		return product;
	}
	
	// display products' list
	public void displayproductslist() {
		System.out.println(this.name+"'s product list:");
		int index=1;
		for(Product product:products) {
			System.out.println("Product No."+index+":"+product.getinf());
			index++;
		}
		System.out.println("");
	}
	
	// get department's information
	public String getinf() {
		return (this.name);
	}
	
	// set a manager to manage the department
	public void setmanager(Manager manager) {
		this.manager[0]=manager;
		manager.department[0]=this;
		}
	
	// get manager's information who manage this department
	public String getmanagerinf() {
		return this.manager[0].getinf();
	}
}
