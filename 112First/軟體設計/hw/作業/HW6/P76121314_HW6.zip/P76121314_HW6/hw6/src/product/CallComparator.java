package product;
import java.util.Comparator;
public class CallComparator implements Comparator<Call> {

	@Override
	public int compare(Call call1, Call call2) {
		// TODO Auto-generated method stub
		return call1.getFloor() - call2.getFloor();
	}

}
