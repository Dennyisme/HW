package product;

public class Monitor {
	
	public int displayCurrentFloor(int currentFloor) {
		System.out.println("Currnet floor: " + currentFloor);
		return currentFloor;
	}
}
