package product;

public class Call {
	private final int currentFloor;
	private final Direction direction;
	private int requireFloor;
	
	public Call(int floor, Direction direction, int requireFloor) {
		this.currentFloor = floor;
		this.direction = direction;
		this.requireFloor = requireFloor;
	}
	
	public int getFloor() {
		return this.currentFloor;
	}
	
	public Direction getDirection() {
		return this.direction;
	}
	
	public int getRequireFloor() {
		return this.requireFloor;
	}
}

