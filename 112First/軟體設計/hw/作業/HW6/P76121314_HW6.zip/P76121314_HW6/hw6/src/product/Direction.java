package product;

public enum Direction {
		UP, DOWN, STOP;
}
