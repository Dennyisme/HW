package product;
import java.util.ArrayList;
import  java.util.Collections;
import java.util.TreeSet;
import java.util.List;

public class Lift {
	private final String id;
	private  int currentFloor, totalFloor;
	private TreeSet<Integer> requireFloor;
	private boolean isDoorOpen;
	private Monitor monitor;
	private Direction direction = Direction.STOP;
	
	
	public Lift(String id, int currentFloor, boolean isDoorOpen, int totalFloor) {
		this.id = id;
		this.currentFloor = currentFloor;
		this.requireFloor = new TreeSet<Integer>(); 
		this.isDoorOpen = isDoorOpen;
		this.monitor = new Monitor();
		this.totalFloor = totalFloor;
	}
	
	public void addRequireFloor(int floor) {
		this.requireFloor.add(floor);
	}

	public void arrive() {
		int arriveFloor = this.currentFloor;
		
		System.out.println("Floor " + arriveFloor + " is arrives.");
		
		if (this.direction == Direction.UP) {
			arriveFloor = this.requireFloor.pollFirst();
		} else {
			arriveFloor = this.requireFloor.pollLast();
		}	
		sound();
	}
	
	private void rise() {
		if (this.currentFloor < this.totalFloor) {
			System.out.println("Lift rising... " + this.direction);
			this.currentFloor ++;
			displayCurrentFloor();
		}
	}

	private void decline() {
		
		if (this.currentFloor > 1) {
			
			System.out.println("Lift declining... " + this.direction);
			this.currentFloor --;
			displayCurrentFloor();
		}
	}

	public int displayCurrentFloor() {
		return this.monitor.displayCurrentFloor(this.currentFloor);
	}
	
	public void called(int callFloor) {
		while (!(callFloor == this.currentFloor)) {
			if (callFloor < this.currentFloor) {
				this.direction = Direction.DOWN;
				decline();
			} else {
				this.direction = Direction.UP;
				rise();
			}
		}
		sound();
	}
	
	public int liftOperation() {
		System.out.println(this.requireFloor);
		if (this.requireFloor.isEmpty()) {
			return -1;
		}
		
		if (this.currentFloor > this.requireFloor.last()) {
			this.direction = Direction.DOWN;
		} else if (this.currentFloor < this.requireFloor.first()){
			this.direction = Direction.UP;
		} 
		
		while (!this.requireFloor.isEmpty()) {
			
			if (this.direction == Direction.UP) {
				while(this.currentFloor != this.requireFloor.first()) {
					rise();
				}
			} else if (this.direction == Direction.DOWN) {
				while(this.currentFloor != this.requireFloor.last()) {
					decline();	
				}
			}
			arrive();
		}
		
		return this.currentFloor;
	}
	
	public void liftStop() {
		this.direction = Direction.STOP;
	}
	
	public String getId() {
		return this.id;
	}
	
	public int getCurrentFloor() {
		return this.currentFloor;
	}
	
	public TreeSet<Integer> getRequireFloor() {
		return this.requireFloor;
	}
	
	public boolean getisDoorOpen() {
		return this.isDoorOpen;
	}
	
	public Direction getDirection() {
		return this.direction;
	}
	
	public Monitor getMonitor() {
		return this.monitor;
	}
	
	public int sound() {
		Sound sound = new Sound();
		return sound.DING();
	}
}
