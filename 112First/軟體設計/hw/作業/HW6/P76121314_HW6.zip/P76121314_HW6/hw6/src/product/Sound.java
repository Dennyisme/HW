package product;

public class Sound {
	public int DING() {
		System.out.println("DING");
		return 1;
	}
}
