package product;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

import java.util.Collections;

public class LiftSystem {
//	private List<Integer> totalFloors;
	private List<Lift> LiftList;
	private List<Call> callQueue;
	
	public LiftSystem(List<Lift> LiftList, List<Call> calls) {

		this.LiftList = LiftList;
		this.callQueue = calls;
	}
	
	public void addCalled(Call call) {
		callQueue.add(call);
		Collections.sort(callQueue, new CallComparator());
	}
	
	public void handleCallQueue() {
		for (Call call : callQueue) {
		    assignmentCall(call);
		}
		callQueue.clear();
	}
	
	public void assignmentCall(Call call) {
		if (!LiftList.isEmpty()) {
			for (Lift lift:LiftList) {
				if (lift.getDirection() == Direction.STOP||
					(lift.getCurrentFloor() > call.getFloor()&&(lift.getDirection() == Direction.DOWN&&call.getDirection() == Direction.DOWN))||
					(lift.getCurrentFloor() < call.getFloor()&&(lift.getDirection() == Direction.UP&&call.getDirection() == Direction.UP))) {
//					System.out.println(call.getRequireFloor());
					lift.called(call.getFloor());
					lift.addRequireFloor(call.getRequireFloor());
					System.out.println("Enter lift " + lift.getId());
					break;
				} else {
					System.out.println("Lift " + lift.getId() + " can not called.");
				}
			}
		}else {
			System.out.println("No lift.");
		}
	}
	
	public List<Lift> getLiftList() {
		return this.LiftList;
	}
}
