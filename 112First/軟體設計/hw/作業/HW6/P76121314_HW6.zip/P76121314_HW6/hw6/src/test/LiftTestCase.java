package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

import product.Call;
import product.Direction;
import product.Lift;
import product.LiftSystem;
import org.junit.jupiter.api.Assertions.*;

public class LiftTestCase {
	int totalFloor = 10;
	@Test
	void DINGTest() {
		Lift liftA = new Lift("A", 1, false, totalFloor);
		assertEquals(1, liftA.sound());
		System.out.println("===========================================");
	}
	
	@Test
	void MonitorOperation() {
		Lift liftA = new Lift("A", 1, false, totalFloor);
		Call call1 = new Call(6, Direction.UP, 9);
		
		List<Lift> liftList = Arrays.asList(liftA);
		List<Call> calls = new ArrayList<>(Arrays.asList(call1));
	
		LiftSystem liftSystem = new LiftSystem(liftList, calls);
		
		int cuurentFloor = liftA.displayCurrentFloor();
		assertEquals(1, cuurentFloor);
		
		liftSystem.handleCallQueue();
		cuurentFloor = liftA.displayCurrentFloor();
		assertEquals(6, cuurentFloor);
		
		liftA.liftOperation();
		cuurentFloor = liftA.displayCurrentFloor();
		assertEquals(9, cuurentFloor);
		System.out.println("===========================================");
	}
	
	
	
	@Test
	void CallrequirAssignmentToLift() {
		Lift liftA = new Lift("A", 1, false, totalFloor);
		Lift liftB = new Lift("B", 6, false, totalFloor);
		List<Lift> liftList = Arrays.asList(liftA, liftB);
		
		Call call1 = new Call(2, Direction.UP, 7);
		List<Call> calls = new ArrayList<>(Arrays.asList(call1));
		
		LiftSystem liftSystem = new LiftSystem(liftList, calls);
		liftSystem.handleCallQueue();
		
		Call call2 = new Call(4, Direction.DOWN, 1);
		calls.add(call2);
		liftSystem.handleCallQueue();
		
		TreeSet<Integer> requireFloorA = liftA.getRequireFloor();
		TreeSet<Integer> answerA = new TreeSet<>();
		answerA.add(7);
		assertEquals(answerA , requireFloorA);
		
		TreeSet<Integer> requireFloorB = liftB.getRequireFloor();
		TreeSet<Integer> answerB = new TreeSet<>();
		answerB.add(1);
		assertEquals(answerB , requireFloorB);
		System.out.println("===========================================");
	}
	
	@Test
	void DirectionTest() {
		Lift liftA = new Lift("A", 1, false, totalFloor);
		Lift liftB = new Lift("B", 6, false, totalFloor);
		Lift liftC = new Lift("C", 1, false, totalFloor);
	
		List<Lift> liftList = Arrays.asList(liftA, liftB, liftC);
		Call call1 = new Call(3, Direction.UP, 8);
		Call call2 = new Call(4, Direction.UP, 6);
		List<Call> calls = new ArrayList<>(Arrays.asList(call1, call2));
		LiftSystem liftSystem = new LiftSystem(liftList, calls);
		liftSystem.handleCallQueue();
		
		Call call3 = new Call(4, Direction.DOWN, 2);
		liftSystem.addCalled(call3);
		liftSystem.handleCallQueue();
		
		liftA.liftOperation();
		assertEquals(Direction.UP, liftA.getDirection());
		
		liftA.liftStop();
		assertEquals(Direction.STOP, liftA.getDirection());
		
		liftB.liftOperation();
		assertEquals(Direction.DOWN, liftB.getDirection());
		
		liftB.liftStop();
		assertEquals(Direction.STOP, liftB.getDirection());
		
		liftC.liftOperation();
		assertEquals(Direction.STOP, liftC.getDirection());
		System.out.println("===========================================");
	}
	
	@Test
	void liftSystem2callsWith3liftsTest() {
		Lift liftA = new Lift("A", 1, false, totalFloor);
		Lift liftB = new Lift("B", 6, false, totalFloor);
		Lift liftC = new Lift("C", 1, false, totalFloor);
	
		List<Lift> liftList = Arrays.asList(liftA, liftB, liftC);
		Call call1 = new Call(2, Direction.UP, 9);
		Call call2 = new Call(3, Direction.UP, 6);
		List<Call> calls = new ArrayList<>(Arrays.asList(call1, call2));
		LiftSystem liftSystem = new LiftSystem(liftList, calls);
		liftSystem.handleCallQueue();
		
		Call call3 = new Call(4, Direction.DOWN, 2);
		liftSystem.addCalled(call3);
		liftSystem.handleCallQueue();
		
		int resultA = liftA.liftOperation();
		assertEquals(9, resultA);
		
		int resultB = liftB.liftOperation();
		assertEquals(2, resultB);
		System.out.println("===========================================");
	}
	
	
	
//	@Test
//	void oneLift() {
//		Lift liftA = new Lift("A", 1, false);
//		assertEquals(1,liftA.getCurrentFloor());
//	}
}
