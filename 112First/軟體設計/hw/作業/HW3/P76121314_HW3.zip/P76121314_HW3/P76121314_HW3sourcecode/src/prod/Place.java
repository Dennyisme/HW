package prod;

import java.util.ArrayList;

public class Place {
	private Question popQuestions, scienceQuestions, sportsQuestions, rockQuestions;
	private int[] places;
	private int placelimit = 12;
	public Place(int playerNumberLimit) {
		popQuestions = new Question("Pop");
		scienceQuestions = new Question("Science");
		sportsQuestions = new Question("Sport");
		rockQuestions = new Question("Rock");
		places = new int[playerNumberLimit];;
	}
	
	public void addPlayer(int lastnumber) {
		places[lastnumber] = 0;
	}
	
	public int getPlace(int currentPlayer) {
		return places[currentPlayer];
	}
	
	public void askQuestion(int currentPlayer) {
		String categery = currentCategory(currentPlayer);
		System.out.println("The category is " + categery);
		if (categery == "Pop") popQuestions.displayQuestion();
		if (categery == "Science") scienceQuestions.displayQuestion();
		if (categery == "Sports") sportsQuestions.displayQuestion();
		if (categery == "Rock") rockQuestions.displayQuestion();
	}
	
	private String currentCategory(int currentPlayer) {
		if (places[currentPlayer]%4 == 0) return "Pop";
		if (places[currentPlayer]%4 == 1) return "Science";
		if (places[currentPlayer]%4 == 2) return "Sports";
		return "Rock";
	}
	
	public void addroll(int currentPlayer, int roll) {
		places[currentPlayer] += roll;
		if (places[currentPlayer] >= placelimit) places[currentPlayer] -= placelimit;
	}
}
