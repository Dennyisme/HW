package prod;

import java.util.ArrayList;

public class Player{
	private String name;
	private int purse;
	private boolean inPenaltyBox;
	
	public Player (String name) {
		this.name = name;
		this.purse = 0;
		this.inPenaltyBox = false;
	}
	
	public void addpurse() {
		this.purse++;
	}
	
	public void setinPenaltyBox(boolean value) {
		this.inPenaltyBox = value;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getPurse() {
		return this.purse;
	}
	
	public boolean isinPenaltyBox() {
		return this.inPenaltyBox;
	}
	
	public boolean didPlayerWin() {
		return !(purse == 6);
	}
}
