package prod;

public class Question {
	private int index = 0;
	private String category;
	
	public Question(String _category) {
		this.category = _category;
	}
	
	public void displayQuestion() {
		System.out.println(this.category + " Question " + index);
		index ++;
	}
	
	
}
