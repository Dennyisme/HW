package prod;
import java.util.ArrayList;
import java.util.LinkedList;

public class Game {
	private ArrayList<Player> players;
	private Place places;
	private int currentPlayer = 0;
    private int _playerNumberLimit;
   
    public  Game(int playerNumberLimit){
    	players = new ArrayList<Player>(playerNumberLimit);
    	places = new Place(playerNumberLimit);
    	_playerNumberLimit = playerNumberLimit;
    }
    
    private int howManyPlayers() {
		return players.size();
	}
    
   public boolean isPlayable() {
		return (howManyPlayers() >= 2);
	}
    
    public void add(String playerName) {
    	if (howManyPlayers() < _playerNumberLimit) {
    		Player player = new Player(playerName);
			players.add(player);
			places.addPlayer(howManyPlayers()-1);
			System.out.println(playerName + " was added");
		    System.out.println("They are player number " + players.size());
		} else {
		    System.out.println(playerName + " failed to join");
		    }
    }
    
    public void roll(int roll) {
    	Player curplayer = players.get(currentPlayer);
		System.out.println(curplayer.getName() + " is the current player");
		System.out.println("They have rolled a " + roll);

		if (curplayer.isinPenaltyBox()&&roll % 2 == 0) {
			System.out.println(curplayer.getName() + " is not getting out of the penalty box");
			}
			
		else {
			if (curplayer.isinPenaltyBox()) System.out.println(curplayer.getName() + " is getting out of the penalty box");
			curplayer.setinPenaltyBox(false);
			places.addroll(currentPlayer, roll);;
			
			System.out.println(curplayer.getName() 
					+ "'s new location is " 
					+ places.getPlace(currentPlayer));
			places.askQuestion(currentPlayer);
		}
	} 
    
    public boolean wasCorrectlyAnswered() {
    	Player curplayer = players.get(currentPlayer);
		if (!curplayer.isinPenaltyBox()) {
			System.out.println("Answer was corrent!!!!");
			curplayer.addpurse();
			System.out.println(curplayer.getName()
					+ " now has "
					+ curplayer.getPurse()
					+ " Gold Coins.");
		}
		boolean winner = curplayer.didPlayerWin();
		updatecurrentPlayer();
		
		return winner;
	}
    
    private void updatecurrentPlayer() {
    	currentPlayer++;
		if (currentPlayer == players.size()) currentPlayer = 0;
    }
    
    public boolean wrongAnswer(){
    	Player curplayer = players.get(currentPlayer);
		System.out.println("Question was incorrectly answered");
		System.out.println(curplayer.getName()+ " was sent to the penalty box");
		curplayer.setinPenaltyBox(true);		
		updatecurrentPlayer();
		return true;
	}
}